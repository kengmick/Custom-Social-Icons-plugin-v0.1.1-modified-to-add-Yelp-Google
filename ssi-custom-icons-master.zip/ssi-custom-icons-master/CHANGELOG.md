# Changelog

## [0.1.1] - 2017-08-15
### Added
- Prevent fatal error when using XAMPP. Props @kengmick.

## [0.1.0] - 2017-06-13
- Initial release.